import 'package:flutter/foundation.dart';

class AIChatExperimentConfig {
  static const String aiModeTelemetryValue = 'worker_first_experiment';

  static const bool _sendCompactContextFromEnvironment = bool.fromEnvironment(
    'AI_CHAT_SEND_COMPACT_CONTEXT',
    defaultValue: true,
  );

  static const bool _delegateMicroTurnsFromEnvironment = bool.fromEnvironment(
    'AI_CHAT_DELEGATE_MICRO_TURNS',
    defaultValue: true,
  );

  static const bool _useSuitabilityPolicyFromEnvironment = bool.fromEnvironment(
    'AI_CHAT_USE_SUITABILITY_POLICY',
    defaultValue: !kReleaseMode,
  );

  static const bool _useCatalogSearchEngineFromEnvironment =
      bool.fromEnvironment(
        'AI_CHAT_USE_CATALOG_SEARCH_ENGINE',
        defaultValue: !kReleaseMode,
      );

  static const bool _catalogSearchShadowFromEnvironment = bool.fromEnvironment(
    'AI_CHAT_CATALOG_SEARCH_SHADOW',
    defaultValue: false,
  );

  static const bool _toolRouterV1FromEnvironment = bool.fromEnvironment(
    'AI_CHAT_TOOL_ROUTER_V1',
    defaultValue: true,
  );

  static bool? _sendCompactContextOverride;
  static bool? _delegateMicroTurnsOverride;
  static bool? _useSuitabilityPolicyOverride;
  static bool? _useCatalogSearchEngineOverride;
  static bool? _catalogSearchShadowOverride;
  static bool? _toolRouterV1Override;

  static bool get sendCompactContext =>
      _sendCompactContextOverride ?? _sendCompactContextFromEnvironment;

  static bool get delegateMicroTurns =>
      _delegateMicroTurnsOverride ?? _delegateMicroTurnsFromEnvironment;

  static bool get useSuitabilityPolicy =>
      _useSuitabilityPolicyOverride ?? _useSuitabilityPolicyFromEnvironment;

  static bool get useCatalogSearchEngine =>
      _useCatalogSearchEngineOverride ?? _useCatalogSearchEngineFromEnvironment;

  static bool get catalogSearchShadow =>
      _catalogSearchShadowOverride ?? _catalogSearchShadowFromEnvironment;

  static bool get toolRouterV1 =>
      _toolRouterV1Override ?? _toolRouterV1FromEnvironment;

  static void setTestOverrides({
    bool? sendCompactContext,
    bool? delegateMicroTurns,
    bool? useSuitabilityPolicy,
    bool? useCatalogSearchEngine,
    bool? catalogSearchShadow,
    bool? toolRouterV1,
  }) {
    _sendCompactContextOverride = sendCompactContext;
    _delegateMicroTurnsOverride = delegateMicroTurns;
    _useSuitabilityPolicyOverride = useSuitabilityPolicy;
    _useCatalogSearchEngineOverride = useCatalogSearchEngine;
    _catalogSearchShadowOverride = catalogSearchShadow;
    _toolRouterV1Override = toolRouterV1;
  }

  static void resetTestOverrides() {
    _sendCompactContextOverride = null;
    _delegateMicroTurnsOverride = null;
    _useSuitabilityPolicyOverride = null;
    _useCatalogSearchEngineOverride = null;
    _catalogSearchShadowOverride = null;
    _toolRouterV1Override = null;
  }

  const AIChatExperimentConfig._();
}
