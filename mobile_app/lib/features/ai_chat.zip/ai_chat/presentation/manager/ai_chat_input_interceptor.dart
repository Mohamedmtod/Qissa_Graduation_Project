import 'package:perfume_app/features/ai_chat/data/models/session_preferences.dart';
import 'package:perfume_app/features/ai_chat/presentation/manager/ai_chat_text_normalizer.dart';

enum AIChatInterceptKind {
  fantasyNoteLike,
  contradictionLike,
  gibberishLike,
  luxuryBudgetMismatch,
}

class AIChatInterceptResult {
  const AIChatInterceptResult({
    required this.kind,
    required this.issueCode,
    required this.reasonCode,
  });

  final AIChatInterceptKind kind;
  final String issueCode;
  final String reasonCode;
}

class AIChatInputInterceptor {
  static final RegExp _punctuation = RegExp(r'[^\w\s\u0600-\u06FF]');
  static final RegExp _arabicScript = RegExp(r'[\u0600-\u06FF]');
  static final RegExp _latinScript = RegExp(r'[A-Za-z]');
  static final RegExp _digitRegex = RegExp(r'\d');

  static const Set<String> _fantasyTerms = {
    'shawarma',
    'garlic',
    'salted watermelon',
    'watermelon',
    'showerma',
    'شاورما',
    'macbook',
    'laptop',
    'new laptop',
    'توم',
    'ثوم',
    'بطيخ مالح',
    'شاورمه',
  };

  static const Set<String> _compromiseTerms = {
    'balanced',
    'compromise',
    'middle ground',
    'versatile',
  };

  static const Set<String> _luxuryTerms = {
    'luxury',
    'premium',
    'royal',
    'king',
    'queen',
    'fancy',
    'opulent',
    'فخم',
    'افخم',
    'أفخم',
    'ملكي',
    'ملوك',
    'أمراء',
    'امراء',
    'امير',
  };

  static const Set<String> _knownPerfumeWords = {
    'perfume',
    'fragrance',
    'scent',
    'men',
    'women',
    'unisex',
    'budget',
    'office',
    'gym',
    'daily',
    'date',
    'night',
    'summer',
    'winter',
    'spring',
    'autumn',
    'vanilla',
    'amber',
    'musk',
    'oud',
    'rose',
    'citrus',
    'woody',
    'floral',
    'spicy',
    'aquatic',
    'sweet',
    'fresh',
    'clean',
    'عطر',
    'برفان',
    'رجالي',
    'نسائي',
    'للجنسين',
    'ميزانية',
    'جنيه',
    'جامعة',
    'شغل',
    'مكتب',
    'جيم',
    'صيفي',
    'شتوي',
    'فانيليا',
    'عنبر',
    'مسك',
    'عود',
    'ورد',
    'حمضيات',
    'خشب',
    'زهور',
    'حلو',
    'منعش',
    'نظيف',
    'مواعدة',
    'هدية',
  };

  static AIChatInterceptResult? detect(
    String message,
    SessionPreferences preferences,
  ) {
    final normalized = _normalizeInput(message);
    if (normalized.isEmpty) return null;

    if (_isFantasyLike(normalized)) {
      return const AIChatInterceptResult(
        kind: AIChatInterceptKind.fantasyNoteLike,
        issueCode: 'fantasy_note_like',
        reasonCode: 'fantasy_note_like',
      );
    }

    if (_isContradictionLike(normalized)) {
      return const AIChatInterceptResult(
        kind: AIChatInterceptKind.contradictionLike,
        issueCode: 'contradiction_like',
        reasonCode: 'contradiction_like',
      );
    }

    if (_isLuxuryBudgetMismatch(normalized, preferences)) {
      return const AIChatInterceptResult(
        kind: AIChatInterceptKind.luxuryBudgetMismatch,
        issueCode: 'luxury_budget_mismatch',
        reasonCode: 'luxury_budget_mismatch',
      );
    }

    if (_isGibberishLike(normalized)) {
      return const AIChatInterceptResult(
        kind: AIChatInterceptKind.gibberishLike,
        issueCode: 'gibberish_like',
        reasonCode: 'gibberish_like',
      );
    }

    return null;
  }

  static String _normalizeInput(String input) {
    final normalized = AIChatTextNormalizer.normalizeForParsing(input);
    if (normalized.length <= 240) return normalized;
    return normalized.substring(normalized.length - 240);
  }

  static bool _containsAny(String message, Set<String> terms) {
    return terms.any((term) => message.contains(_normalizeInput(term)));
  }

  static bool _isFantasyLike(String message) {
    return _containsAny(message, _fantasyTerms);
  }

  static bool _isLuxuryBudgetMismatch(
    String message,
    SessionPreferences preferences,
  ) {
    final budget = preferences.maxBudget;
    if (budget == null || budget > 300) return false;
    return _containsAny(message, _luxuryTerms);
  }

  static bool _isContradictionLike(String message) {
    if (_containsAny(message, _compromiseTerms)) {
      return false;
    }

    final wantsVeryLight =
        message.contains('light') ||
        message.contains('lighter') ||
        message.contains('invisible') ||
        message.contains('barely noticeable') ||
        message.contains('close to skin') ||
        message.contains('skin scent') ||
        message.contains('خفيف') ||
        message.contains('اهدي') ||
        message.contains('هادي');
    final wantsVeryStrong =
        message.contains('strong') ||
        message.contains('fills the room') ||
        message.contains('fills the whole room') ||
        message.contains('room filling') ||
        message.contains('fills room') ||
        message.contains('lasts forever') ||
        message.contains('beast mode') ||
        message.contains('project') ||
        message.contains('قوي') ||
        message.contains('فواح') ||
        message.contains('بيملي المكان') ||
        message.contains('يملي المكان');
    final wantsUnnoticed =
        message.contains('not noticeable') ||
        message.contains('barely smell') ||
        message.contains('barely noticeable') ||
        message.contains('invisible') ||
        message.contains('close to skin') ||
        message.contains('skin scent') ||
        message.contains('مابيتشمش') ||
        message.contains('ما بيتشمش');

    return (wantsVeryLight && wantsVeryStrong) ||
        (wantsUnnoticed && wantsVeryStrong);
  }

  static bool _isGibberishLike(String message) {
    final cleaned = message.replaceAll(_punctuation, ' ').trim();
    if (cleaned.isEmpty) return false;

    final tokens = cleaned
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList();
    if (tokens.isEmpty) return false;

    final hasKnownWord = tokens.any(
      (token) => _knownPerfumeWords.any(
        (known) =>
            token.contains(_normalizeInput(known)) ||
            _normalizeInput(known).contains(token),
      ),
    );
    if (hasKnownWord) return false;

    final hasArabic = _arabicScript.hasMatch(cleaned);
    final hasLatin = _latinScript.hasMatch(cleaned);
    if (!hasArabic && !hasLatin) return false;
    if (_digitRegex.hasMatch(cleaned)) return false;

    if (tokens.length == 1 && tokens.first.length >= 6) {
      return true;
    }

    if (tokens.length <= 2 && cleaned.length <= 16) {
      return true;
    }

    return false;
  }
}
