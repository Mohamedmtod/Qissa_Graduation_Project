enum AIChatBudgetPolicy { flexible, strict }
