import 'package:perfume_app/features/ai_chat/core/ai_chat_language.dart';
import 'package:perfume_app/features/ai_chat/data/models/recommendation_memory.dart';
import 'package:perfume_app/features/ai_chat/presentation/manager/local_intent_parser.dart';

class AIChatRecommendationMemoryAnswerBuilder {
  const AIChatRecommendationMemoryAnswerBuilder();

  String buildSelectionAnswer(
    List<RecommendedProductRef> selected,
    AIChatLanguage language, {
    required bool wantsCart,
  }) {
    final names = selected
        .map((ref) => ref.name)
        .join(language.isArabic ? ' و' : ' and ');
    if (language.isArabic) {
      final subject = selected.length == 1 ? 'المنتج' : 'المنتجات';
      final cartText = wantsCart
          ? 'لو حابب تضيف $subject للسلة، افتح Details واضغط Add to cart من صفحة المنتج. الشات حاليًا بيوجهك للإضافة وما بيضيفش تلقائيًا.'
          : 'ولو حابب تضيفه للسلة، افتح Details واضغط Add to cart من صفحة المنتج.';
      return 'تمام، تقصد $names. ممكن تفتح Details وتشوف السعر والنوتات والمعلومات أكتر قبل الشراء. $cartText';
    }

    final subject = selected.length == 1 ? 'this product' : 'these products';
    final cartText = wantsCart
        ? 'To add $subject, open Details and tap Add to cart on the product page. The chat can guide you, but it does not add items automatically yet.'
        : 'To add it to the cart, open Details and tap Add to cart on the product page.';
    return 'Got it, you mean $names. You can open Details to check the price, notes, and more information before buying. $cartText';
  }

  String buildMemoryAnswer(
    RecommendedProductRef ref,
    AIChatLanguage language, {
    required bool includeNotes,
    required bool includeReason,
  }) {
    final notes = [
      ...ref.topNotes,
      ...ref.middleNotes,
      ...ref.baseNotes,
      ...ref.notes,
    ].where((note) => note.trim().isNotEmpty).toSet().take(5).join(', ');
    final cleanedReason = cleanUserFacingReason(ref.matchReason);
    final reason = cleanedReason.isNotEmpty
        ? cleanedReason
        : language.isArabic
        ? 'لأنه أقرب ترشيح متاح للتفضيلات التي ذكرتها.'
        : 'It was the closest available match for the preferences you shared.';
    if (language.isArabic) {
      final parts = <String>[
        '${ref.displayIndex}. ${ref.name} من ${ref.brand} بسعر ${ref.price.toStringAsFixed(0)} جنيه.',
      ];
      if (includeNotes || notes.isNotEmpty) {
        parts.add(
          notes.isEmpty
              ? 'لا توجد نوتات تفصيلية كافية لهذا المنتج في البيانات الحالية.'
              : 'أبرز النوتات: $notes.',
        );
      }
      if (includeReason || cleanedReason.isNotEmpty) {
        parts.add('سبب الترشيح: $reason');
      }
      return parts.join(' ');
    }
    final parts = <String>[
      '${ref.displayIndex}. ${ref.name} by ${ref.brand}, ${ref.price.toStringAsFixed(0)} EGP.',
    ];
    if (includeNotes || notes.isNotEmpty) {
      parts.add(
        notes.isEmpty
            ? 'Detailed notes are not available for this product yet.'
            : 'Main notes: $notes.',
      );
    }
    if (includeReason || cleanedReason.isNotEmpty) {
      parts.add('Why I picked it: $reason');
    }
    return parts.join(' ');
  }

  String cleanUserFacingReason(String reason) {
    var cleaned = reason.trim();
    if (cleaned.isEmpty) return '';
    cleaned = cleaned.replaceAll(
      RegExp(r'\s*Suitability:\s*[^.]+\.?', caseSensitive: false),
      '',
    );
    cleaned = cleaned.replaceAll(
      RegExp(r'\b[a-z]+(?:_[a-z0-9]+){1,}\b', caseSensitive: false),
      '',
    );
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ').trim();
    cleaned = cleaned.replaceAll(RegExp(r'\s+([,.])'), r'$1').trim();
    return cleaned;
  }

  String buildCheapestAnswer(
    List<RecommendedProductRef> selected,
    AIChatLanguage language,
  ) {
    final cheapest = selected.reduce((a, b) => a.price <= b.price ? a : b);
    if (language.isArabic) {
      return 'الأرخص بين الاختيارات الظاهرة هو ${cheapest.name} من ${cheapest.brand} بسعر ${cheapest.price.toStringAsFixed(0)} جنيه. لو تحب أشرح مناسب لإيه، افتح Details أو اسألني عنه بالرقم.';
    }
    return 'The cheapest visible option is ${cheapest.name} by ${cheapest.brand} at ${cheapest.price.toStringAsFixed(0)} EGP. If you want, ask about it by number or open Details.';
  }

  String buildComparisonAnswer(
    List<RecommendedProductRef> selected,
    AIChatLanguage language,
  ) {
    final first = selected[0];
    final second = selected[1];
    final firstWeight = _intensityWeight(first.intensity);
    final secondWeight = _intensityWeight(second.intensity);
    final verdict = firstWeight == secondWeight
        ? language.isArabic
              ? 'الاتنين قريبين في الثقل، فاختيارك يكون حسب النوتات والسعر.'
              : 'They are close in weight, so choose by notes and price.'
        : firstWeight > secondWeight
        ? language.isArabic
              ? '${first.name} أثقل من ${second.name}.'
              : '${first.name} is heavier than ${second.name}.'
        : language.isArabic
        ? '${first.name} أخف من ${second.name}.'
        : '${first.name} is lighter than ${second.name}.';
    if (language.isArabic) {
      final firstIntensity = _displayIntensity(first.intensity, language);
      final secondIntensity = _displayIntensity(second.intensity, language);
      return '$verdict ${first.name}: $firstIntensity, ${first.price.toStringAsFixed(0)} جنيه. ${second.name}: $secondIntensity, ${second.price.toStringAsFixed(0)} جنيه.';
    }
    return '$verdict ${first.name}: ${first.intensity}, ${first.price.toStringAsFixed(0)} EGP. ${second.name}: ${second.intensity}, ${second.price.toStringAsFixed(0)} EGP.';
  }

  String buildAmbiguousSelectionAnswer(
    List<RecommendedProductRef> matches,
    AIChatLanguage language,
  ) {
    final options = matches
        .take(3)
        .map((ref) {
          return '${ref.displayIndex}. ${ref.name}';
        })
        .join('\n');
    if (language.isArabic) {
      return 'تقصد أنهي منتج منهم؟\n$options';
    }
    return 'Which product do you mean?\n$options';
  }

  int _intensityWeight(String intensity) {
    switch (LocalIntentParser.normalizeInput(intensity)) {
      case 'strong':
      case 'high':
      case '\u0642\u0648\u064a':
        return 3;
      case 'light':
      case 'soft':
      case '\u062e\u0641\u064a\u0641':
        return 1;
      default:
        return 2;
    }
  }

  String _displayIntensity(String intensity, AIChatLanguage language) {
    if (!language.isArabic) return intensity;
    return switch (LocalIntentParser.normalizeInput(intensity)) {
      'light' => 'هادي',
      'medium' || 'moderate' => 'متوسط',
      'strong' || 'high' => 'قوي',
      _ => intensity,
    };
  }
}
