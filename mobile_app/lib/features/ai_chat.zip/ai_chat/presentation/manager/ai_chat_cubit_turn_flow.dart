part of 'ai_chat_cubit.dart';

extension AIChatCubitTurnFlow on AIChatCubit {
  Map<String, dynamic> _recommendationMemorySnapshot(
    RecommendationMemory memory,
  ) {
    return {
      'lastFocusedProductId': memory.lastFocusedProductId,
      'lastRecommendationBatchId': memory.lastRecommendationBatchId,
      'lastRecommendedProducts': memory.lastRecommendedProducts
          .map((item) => item.toJson())
          .toList(growable: false),
    };
  }

  bool _hasMissingFoundationalDiscoverySlots(
    SessionPreferences preferences, {
    required bool hasRecommendationContext,
  }) {
    if (hasRecommendationContext) return false;
    return preferences.gender == null || preferences.season == null;
  }

  bool _sameNormalizedStringSet(List<String> first, List<String> second) {
    if (identical(first, second)) return true;
    if (first.length != second.length) return false;

    final firstSet = first.map((item) => item.trim().toLowerCase()).toSet();
    final secondSet = second.map((item) => item.trim().toLowerCase()).toSet();
    if (firstSet.length != secondSet.length) return false;
    return firstSet.containsAll(secondSet);
  }

  bool _hasNoteSignalDelta(
    SessionPreferences before,
    SessionPreferences after,
  ) {
    return !_sameNormalizedStringSet(
          before.preferredNotes,
          after.preferredNotes,
        ) ||
        !_sameNormalizedStringSet(
          before.preferredTopNotes,
          after.preferredTopNotes,
        ) ||
        !_sameNormalizedStringSet(
          before.preferredMiddleNotes,
          after.preferredMiddleNotes,
        ) ||
        !_sameNormalizedStringSet(
          before.preferredBaseNotes,
          after.preferredBaseNotes,
        ) ||
        !_sameNormalizedStringSet(before.excludedNotes, after.excludedNotes);
  }

  bool _tryHandleRecommendationContextAnswer(
    String message, {
    required List<ProductModel> catalog,
    required AIChatLanguage language,
    required String sessionId,
    required bool pruneHistoricalBotMessages,
  }) {
    final effectiveRecommendationMemory = _latestVisibleRecommendationMemory();
    if (effectiveRecommendationMemory.lastRecommendedProducts.isEmpty) {
      return false;
    }
    final parsedPreferences = LocalIntentParser.parse(
      message,
      state.preferences,
    );
    if (_preferenceChangeDetector.hasPreferenceDelta(
      state.preferences,
      parsedPreferences,
    )) {
      return false;
    }

    if (!looksLikeProductWhyFollowUp(message) &&
        !looksLikeProductDetailsFollowUp(message)) {
      return false;
    }

    final focusedProductId =
        effectiveRecommendationMemory.lastFocusedProductId ??
        effectiveRecommendationMemory.lastRecommendedProducts.first.productId;
    final focusedProduct = catalog
        .where((product) => product.id == focusedProductId)
        .firstOrNull;
    if (focusedProduct == null) return false;

    final answer = looksLikeProductWhyFollowUp(message)
        ? buildWhyProductFollowUpAnswer(focusedProduct, language)
        : buildProductDetailsFollowUpAnswer(focusedProduct, language);

    _emitState(
      state.copyWith(
        recommendationMemory: effectiveRecommendationMemory.copyWith(
          lastFocusedProductId: focusedProduct.id,
        ),
      ),
    );

    _replyHandler.handleAnswerReply(
      AIChatReply.answer(answer: answer, updatedPreferences: state.preferences),
      language: language,
      source: looksLikeProductWhyFollowUp(message)
          ? 'recommendation_product_why'
          : 'recommendation_product_details',
      sessionId: sessionId,
      pruneHistoricalBotMessages: pruneHistoricalBotMessages,
    );
    return true;
  }

  RecommendationMemory _latestVisibleRecommendationMemory() {
    return latestVisibleRecommendationMemory(
      state.messages,
      state.recommendationMemory,
    );
  }

  AIChatTurnContext? _validateIncomingMessage(String text) {
    final effectiveRecommendationMemory = _latestVisibleRecommendationMemory();
    final validation = _turnService.validateAndBuildContext(
      text: text,
      state: state,
      sessionId: _sessionId,
      effectiveRecommendationMemory: effectiveRecommendationMemory,
      requestTimestampsMs: _requestTimestampsMs,
      shouldContinueAvailabilityClarification:
          _shouldContinueAvailabilityClarification,
      maxUserMessageLength: AIChatCubit.maxUserMessageLength,
      maxRequestsPerWindow: AIChatCubit._maxRequestsPerWindow,
      rateLimitWindow: AIChatCubit._rateLimitWindow,
    );
    if (validation.accepted) return validation.context;
    if (validation.rejection == AIChatTurnRejection.emptyOrLoading) {
      return null;
    }

    if (validation.rejection == AIChatTurnRejection.tooLong) {
      _logDebug(
        'Rejected user message: too long | len=${validation.trimmed.length} | max=${AIChatCubit.maxUserMessageLength} | text="${_shortText(validation.trimmed)}"',
      );
      _emitState(
        state.copyWith(
          language: validation.responseLanguage,
          errorMessage: _t(
            validation.responseLanguage,
            ar: 'رسالتك طويلة جدًا. اختصرها إلى ${AIChatCubit.maxUserMessageLength} حرف أو أقل واحتفظ بالتفاصيل الأساسية فقط.',
            en: 'Your message is too long. Please shorten it to ${AIChatCubit.maxUserMessageLength} characters or less and keep only the key details.',
          ),
        ),
      );
      return null;
    }

    if (validation.rejection == AIChatTurnRejection.cooldown) {
      _logDebug(
        'Rejected user message: cooldown active | remaining=${state.cooldownSecondsRemaining}s | text="${_shortText(validation.trimmed)}"',
      );
      _emitState(
        state.copyWith(
          language: validation.responseLanguage,
          errorMessage: _t(
            validation.responseLanguage,
            ar: 'من فضلك انتظر ${state.cooldownSecondsRemaining} ثانية قبل إرسال رسالة أخرى.',
            en: 'Please wait ${state.cooldownSecondsRemaining} seconds before sending another message.',
          ),
        ),
      );
      return null;
    }

    if (validation.rejection == AIChatTurnRejection.rateLimit) {
      _logDebug(
        'Rejected user message: local rate limit exceeded | windowCount=${validation.rateLimitWindowCount} | text="${_shortText(validation.trimmed)}"',
      );
      _emitState(
        state.copyWith(
          language: validation.responseLanguage,
          errorMessage: _t(
            validation.responseLanguage,
            ar: 'وصلت للحد المؤقت للرسائل. حاول مرة أخرى بعد دقيقة.',
            en: 'You reached the temporary message limit. Please try again in a minute.',
          ),
        ),
      );
      return null;
    }

    return null;
  }

  void _prepareActiveTurn(
    AIChatTurnContext incoming, {
    required bool pruneHistoricalBotMessages,
  }) {
    _logDebug(
      'Preparing active turn | sessionId=${incoming.activeSessionId} | requestId=${incoming.requestId} | '
      'status=${state.status.name} | messageCount=${state.messages.length} | '
      'prefs=${state.preferences.toJson()}',
    );
    unawaited(
      _aiChatRepo.logAIChatEvent(
        eventType: 'message_sent',
        sessionId: incoming.activeSessionId,
        metadata: {
          'ai_mode': _currentAiModeTelemetryValue(),
          'messageLength': incoming.trimmed.length,
          'activeCriteriaCount': state.preferences.activeCriteriaCount,
          'requestId': incoming.requestId,
        },
      ),
    );
    unawaited(
      _aiChatRepo.saveAIChatDebugLog(
        phase: 'turn_started',
        sessionId: incoming.activeSessionId,
        requestId: incoming.requestId,
        language: incoming.responseLanguage.code,
        messageText: incoming.trimmed,
        detectedIntent: incoming.intent.name,
        responseSource: 'incoming_turn',
        preferencesSnapshot: state.preferences.toJson(),
        availabilityContextSnapshot: {
          'lastQuery': state.availabilityContext.lastQuery,
          'matchedProductId': state.availabilityContext.matchedProductId,
          'matchedProductName': state.availabilityContext.matchedProductName,
          'availabilityStatus':
              state.availabilityContext.availabilityStatus.name,
          'referenceProfileKey': state.availabilityContext.referenceProfileKey,
          'candidateOptionIds': state.availabilityContext.candidateOptionIds,
          'externalCandidates': state.availabilityContext.externalCandidates
              .map((item) => item.toMap())
              .toList(growable: false),
          'source': state.availabilityContext.source,
        },
        recommendationMemorySnapshot: _recommendationMemorySnapshot(
          incoming.effectiveRecommendationMemory,
        ),
      ),
    );

    final userMessage = AIChatMessage.user(incoming.trimmed);
    final updatedMessages =
        pruneBotHistoryForFreshTurn(
            localizedOpeningMessages(
              List<AIChatMessage>.from(state.messages),
              incoming.responseLanguage,
            ),
            enabled: pruneHistoricalBotMessages,
          )
          ..add(userMessage)
          ..add(AIChatMessage.loading());

    _emitState(
      state.copyWith(
        status: AIChatStatus.loading,
        messages: updatedMessages,
        language: incoming.responseLanguage,
        errorMessage: null,
        loadingPhase: AIChatCubit._loadingPhaseAnalyzing,
        recommendationMemory: incoming.effectiveRecommendationMemory,
      ),
    );

    _sessionPersistenceHelper.enqueueMessagePersistence(
      message: userMessage,
      sessionId: incoming.activeSessionId,
    );
  }

  Future<bool> _handleEarlyContextAnswers(
    AIChatTurnContext incoming,
    List<ProductModel> catalog, {
    required bool pruneHistoricalBotMessages,
  }) async {
    if (await _tryHandleAvailabilityContextAnswer(
      incoming.trimmed,
      catalog: catalog,
      language: incoming.responseLanguage,
      sessionId: incoming.activeSessionId,
      pruneHistoricalBotMessages: pruneHistoricalBotMessages,
    )) {
      return true;
    }

    if (_tryHandleRecommendationContextAnswer(
      incoming.trimmed,
      catalog: catalog,
      language: incoming.responseLanguage,
      sessionId: incoming.activeSessionId,
      pruneHistoricalBotMessages: pruneHistoricalBotMessages,
    )) {
      return true;
    }

    return false;
  }

  bool _handleFantasyNoteInterception(
    AIChatTurnContext incoming, {
    required bool pruneHistoricalBotMessages,
  }) {
    if (incoming.shouldContinueAvailabilityClarification ||
        incoming.isGreetingOnly) {
      return false;
    }

    final parsedForInterceptor = LocalIntentParser.parse(
      incoming.trimmed,
      state.preferences,
    );
    final intercepted = AIChatInputInterceptor.detect(
      incoming.trimmed,
      parsedForInterceptor,
    );
    if (intercepted?.kind != AIChatInterceptKind.fantasyNoteLike) {
      return false;
    }

    _replyHandler.handleAskReply(
      AIChatReply.ask(
        question: buildInterceptedClarificationMessage(
          intercepted!,
          incoming.responseLanguage,
        ),
        updatedPreferences: parsedForInterceptor,
      ),
      language: incoming.responseLanguage,
      source: 'local_interceptor',
      issueCode: intercepted.issueCode,
      reasonCode: intercepted.reasonCode,
      sessionId: incoming.activeSessionId,
      pruneHistoricalBotMessages: pruneHistoricalBotMessages,
    );
    return true;
  }

  bool _handleEarlyInterception(
    AIChatTurnContext incoming, {
    required bool pruneHistoricalBotMessages,
  }) {
    final shouldRunEarlyInterceptor =
        incoming.intent != AIChatIntent.followUpProduct &&
        incoming.intent != AIChatIntent.compareProducts &&
        incoming.intent != AIChatIntent.summary &&
        !incoming.shouldContinueAvailabilityClarification &&
        !incoming.isGreetingOnly;

    if (shouldRunEarlyInterceptor) {
      final parsedForInterceptor = LocalIntentParser.parse(
        incoming.trimmed,
        state.preferences,
      );
      final hasRecommendationContext = incoming
          .effectiveRecommendationMemory
          .lastRecommendedProducts
          .isNotEmpty;
      if (_isPersonaOnlyMessageForLocalAsk(incoming, parsedForInterceptor)) {
        final missingSlots = parsedForInterceptor.missingSlotsForNextQuestion(
          hasRecommendationContext: hasRecommendationContext,
        );
        final nextSlot = missingSlots.isNotEmpty
            ? missingSlots.first
            : 'notesOrIntensity';
        _replyHandler.handleAskReply(
          AIChatReply.ask(
            question: buildQuestionForMissingSlot(
              nextSlot,
              incoming.responseLanguage,
            ),
            updatedPreferences: parsedForInterceptor,
          ),
          language: incoming.responseLanguage,
          source: 'persona_only_interceptor',
          issueCode: 'partial_persona_preferences',
          reasonCode: 'persona_only_local_ask',
          sessionId: incoming.activeSessionId,
          pruneHistoricalBotMessages: pruneHistoricalBotMessages,
        );
        return true;
      }

      var intercepted = AIChatInputInterceptor.detect(
        incoming.trimmed,
        parsedForInterceptor,
      );
      final hasMeaningfulExistingContext =
          state.preferences.activeCriteriaCount > 0 || hasRecommendationContext;
      if (intercepted?.kind == AIChatInterceptKind.gibberishLike &&
          hasMeaningfulExistingContext) {
        intercepted = null;
      }
      if (incoming.intent == AIChatIntent.availabilityCheck &&
          intercepted != null &&
          intercepted.kind != AIChatInterceptKind.fantasyNoteLike) {
        intercepted = null;
      }
      if (intercepted != null) {
        _replyHandler.handleAskReply(
          AIChatReply.ask(
            question: buildInterceptedClarificationMessage(
              intercepted,
              incoming.responseLanguage,
            ),
            updatedPreferences: parsedForInterceptor,
          ),
          language: incoming.responseLanguage,
          source: 'local_interceptor',
          issueCode: intercepted.issueCode,
          reasonCode: intercepted.reasonCode,
          sessionId: incoming.activeSessionId,
          pruneHistoricalBotMessages: pruneHistoricalBotMessages,
        );
        return true;
      }
    }

    if (incoming.intent == AIChatIntent.summary) {
      _replyHandler.handleAnswerReply(
        AIChatReply.answer(
          answer: buildPreferenceSummary(
            state.preferences,
            language: incoming.responseLanguage,
          ),
          updatedPreferences: state.preferences,
        ),
        language: incoming.responseLanguage,
        source: 'local_summary',
        sessionId: incoming.activeSessionId,
        pruneHistoricalBotMessages: true,
      );
      return true;
    }

    return false;
  }

  bool _isPersonaOnlyMessageForLocalAsk(
    AIChatTurnContext incoming,
    SessionPreferences parsedPreferences,
  ) {
    if (incoming.intent == AIChatIntent.availabilityCheck ||
        incoming.intent == AIChatIntent.followUpProduct ||
        incoming.intent == AIChatIntent.compareProducts ||
        incoming.intent == AIChatIntent.summary ||
        incoming.isGreetingOnly ||
        incoming.shouldContinueAvailabilityClarification) {
      return false;
    }

    final normalized = LocalIntentParser.normalizeInput(incoming.trimmed);
    if (normalized.isEmpty) return false;
    if (AvailabilityIntentUtils.looksLikeRecommendationContinuationCommand(
      normalized,
    )) {
      return false;
    }
    if (LocalIntentParser.containsAny(
          normalized,
          AvailabilityIntentUtils.availabilityKeywords,
        ) ||
        normalized.contains('recommend') ||
        normalized.contains('suggest') ||
        normalized.contains('show me')) {
      return false;
    }
    if (!_looksLikeNarrowPersonaOnlyStatement(normalized)) {
      return false;
    }
    if (parsedPreferences.activeCriteriaCount > 1) return false;
    if (parsedPreferences.hasAnyNoteSignal) return false;
    if (parsedPreferences.maxBudget != null) return false;

    return true;
  }

  bool _looksLikeNarrowPersonaOnlyStatement(String normalized) {
    final agePattern = RegExp(
      r'\b\d{1,2}\s*(?:year old|years old|yr old|yrs old)\b',
    );
    final hyphenAgePattern = RegExp(r'\b\d{1,2}\s*-\s*year\s*-\s*old\b');
    final explicitPersonaGender = RegExp(
      r"\b(i am|im|i'm)\s+(?:a\s+)?(?:\d{1,2}\s*(?:-\s*)?year\s*(?:-\s*)?old\s+)?(?:man|male|woman|female)\b",
    );
    return agePattern.hasMatch(normalized) ||
        hyphenAgePattern.hasMatch(normalized) ||
        explicitPersonaGender.hasMatch(normalized) ||
        normalized.contains('i work') ||
        normalized.contains('i am working') ||
        normalized.contains("i'm working") ||
        normalized.contains('im working');
  }
}
