class AIChatFeedback {
  const AIChatFeedback({
    required this.sessionId,
    required this.messageId,
    required this.isHelpful,
    this.note,
  });

  final String sessionId;
  final String messageId;
  final bool isHelpful;
  final String? note;

  String get feedbackValue => isHelpful ? 'up' : 'down';
}
