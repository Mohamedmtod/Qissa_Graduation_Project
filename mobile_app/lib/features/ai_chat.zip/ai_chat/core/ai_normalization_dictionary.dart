/// Canonical values and their common aliases / translations for the AI feature.
///
/// This dictionary standardizes all scattered values (like "Vanilla", "فانيليا", "فانيلا")
/// into a single, clean canonical value (e.g. "vanilla") so the local ranking and
/// AI Worker both understand exactly what is meant without strict string equality issues.
class AINormalizationDictionary {
  // ── 1. Canonical Lists ────────────────────────────────────────────────

  static const List<String> canonicalGenders = ['men', 'women', 'unisex'];
  static const List<String> canonicalIntensities = [
    'light',
    'medium',
    'strong',
  ];
  static const List<String> canonicalSeasons = [
    'summer',
    'winter',
    'spring',
    'autumn',
    'all_seasons',
  ];
  static const List<String> canonicalOccasions = [
    'daily',
    'university',
    'office',
    'formal',
    'evening',
    'date',
    'casual',
    'gift',
  ];
  static const List<String> canonicalTimes = ['day', 'night', 'all_day'];
  static const List<String> canonicalNoteLayers = ['top', 'middle', 'base'];

  static const List<String> canonicalNotes = [
    'sweet',
    'sugary',
    'vanilla',
    'amber',
    'musk',
    'oud',
    'rose',
    'jasmine',
    'citrus',
    'cedar',
    'sandalwood',
    'woody',
    'floral',
    'spicy',
    'powdery',
    'fruity',
    'leather',
    'aquatic',
    'tobacco',
    'honey',
    'pepper',
    'ambroxan',
  ];

  static const List<String> canonicalTags = [
    'sweet',
    'sugary',
    'fresh',
    'clean',
    'powdery',
    'smoky',
    'musky',
    'warm',
    'romantic',
    'elegant',
    'bold',
    'classic',
    'masculine',
    'gift',
    'open_budget',
  ];

  // ── 2. Synonym / Alias Maps (Grouped / Human-Readable) ─────────────────

  static const Map<String, List<String>> genderAliases = {
    'men': ['mens', 'رجالي', 'للرجال', 'male'],
    'women': ['womens', 'نسائي', 'حريمي', 'للنساء', 'female'],
    'unisex': ['للجنسين', 'يوني سكس'],
  };

  static const Map<String, List<String>> intensityAliases = {
    'light': [
      'خفيف',
      'هادي',
      'اهدى',
      'أهدى',
      'soft',
      'lighter',
      'lighten',
      'less intense',
      'gentler',
      'relaxing',
      'quiet',
      'calm',
    ],
    'medium': ['متوسط', 'معتدل'],
    'strong': [
      'قوي',
      'ثقيل',
      'فواح',
      'heavy',
      'ثابت',
      'long lasting',
      'long-lasting',
      'lasting',
      'projecting',
    ],
  };

  static const Map<String, List<String>> seasonAliases = {
    'summer': ['صيفي', 'للصيف', 'حر'],
    'winter': ['شتوي', 'للشتاء', 'برد'],
    'spring': ['ربيع'],
    'autumn': ['خريف', 'fall'],
    'all_seasons': [
      'كل الفصول',
      'all season',
      'all seasons',
      'طول السنة',
      'اي موسم',
      'أي موسم',
    ],
  };

  static const Map<String, List<String>> occasionAliases = {
    'daily': ['يومي', 'كل يوم', 'عادي', 'school'],
    'university': ['college', 'campus', 'جامعة', 'كليتي'],
    'office': [
      'work',
      'office',
      'شغل',
      'للشغل',
      'دوام',
      'مكتب',
      'شغل',
      'دوام',
      'مكتب',
      'interview',
      'انترفيو',
      'مقابله شغل',
      'مقابلة شغل',
    ],
    'formal': [
      'رسمي',
      'مناسبات',
      'زواج',
      'tuxedo',
      'بدله',
      'بدلة',
      'wedding',
      'engagement',
      'خطوبة',
      'فرح',
    ],
    'evening': ['سهرة', 'party', 'حفلة'],
    'date': ['غرامي', 'موعد'],
    'casual': ['طلعات', 'خروجات', 'مفتوح'],
  };

  static const Map<String, List<String>> timeAliases = {
    'day': [
      'morning',
      'daytime',
      'نهار',
      'صباحي',
      'للنهار',
      'النهار',
      'الصباحي',
    ],
    'night': [
      'evening',
      'late night',
      'ليل',
      'مساء',
      'لليل',
      'الليل',
      'المساء',
      'ليلي',
      'الليلي',
    ],
    'all_day': ['طول اليوم', 'في أي وقت', 'anytime', 'long day'],
  };

  static const Map<String, List<String>> noteAliases = {
    'vanilla': [
      'vanila',
      'vanilaa',
      'vannila',
      'فانيليا',
      'فانيلا',
      'الفانيليا',
      'الفانيلا',
    ],
    'amber': ['عنبر', 'العنبر'],
    'musk': ['musky', 'مسك', 'المسك'],
    'oud': ['عود', 'العود'],
    'woody': [
      'wood',
      'woods',
      'خشب',
      'اخشاب',
      'خشبي',
      'الخشب',
      'الاخشاب',
      'الخشبي',
    ],
    'sandalwood': [
      'sandal',
      '\u0635\u0646\u062f\u0644',
      '\u0627\u0644\u0635\u0646\u062f\u0644',
      '\u062e\u0634\u0628 \u0635\u0646\u062f\u0644',
      '\u062e\u0634\u0628 \u0627\u0644\u0635\u0646\u062f\u0644',
      '\u062e\u0634\u0628 \u0627\u0644\u0635\u0646\u062f\u0644',
    ],
    'citrus': [
      'citrusy',
      'lemon',
      'orange',
      'حمضيات',
      'ليمون',
      'برتقال',
      'الحمضيات',
      'الليمون',
      'البرتقال',
    ],
    'rose': ['ورد', 'ورود', 'الورد', 'الورود'],
    'floral': ['زهور', 'ياسمين', 'الزهور', 'الياسمين'],
    'spicy': ['توابل', 'سبايسي', 'حار', 'التوابل', 'الحار'],
    'powdery': ['بودر', 'بودري', 'البودر', 'البودري'],
    'fruity': ['فواكه', 'فاكهة', 'فاكهي', 'الفواكه', 'الفاكهة', 'الفاكهي'],
    'leather': ['جلد', 'جلود', 'ليذر', 'الجلد', 'الجلود'],
    'aquatic': ['مائي', 'بحر', 'المائي', 'البحر'],
    'tobacco': [
      'tobaco',
      'tabacco',
      'تبغ',
      'التبغ',
      'توباكو',
      'توباكوو',
      'دخان',
      'دخاني',
      'أوراق التبغ',
      'اوراق التبغ',
      'زهر التبغ',
    ],
    'honey': [
      'عسل',
      'العسل',
      'عسلي',
      'شمع العسل',
      'زهر العسل',
      'honeyed',
      'beeswax',
    ],
    'pepper': [
      'pepper',
      'black pepper',
      'pink pepper',
      'فلفل',
      'الفلفل',
      'فلفلي',
      'فلفل اسود',
      'فلفل أسود',
      'فلفل وردي',
    ],
    'ambroxan': [
      'ambroxan',
      'ambrox',
      'ambroksan',
      'امبروكسان',
      'أمبروكسان',
      'الامبروكسان',
      'الأمبروكسان',
    ],
  };

  static const Map<String, List<String>> tagAliases = {
    'sweet': ['سويت', 'الحلو المسكر'],
    'sugary': ['مسكر', 'سكر', 'المسكر'],
    'fresh': ['منعش', 'المنعش', 'فريش', 'fresh', 'ultra fresh'],
    'clean': ['نظافة', 'صابون', 'النظافة', 'نضيف', 'نضيفة', 'clean'],
    'smoky': ['دخان', 'دُخاني', 'الدخان', 'الدخاني'],
    'warm': ['دافئ', 'دفا', 'الدافئ'],
    'romantic': ['romantic', 'valentine'],
    'gift': ['gift', 'present', 'هدية', 'هديه', 'اهدي', 'أهدي', 'للإهداء'],
    'elegant': [
      'أنيق',
      'فخم',
      'الأنيق',
      'الفخم',
      'boss',
      'masterpiece',
      'vip',
      'professional',
    ],
    'bold': ['جريء', 'قوي', 'الجريء', 'القوي', 'masterpiece'],
    'classic': ['كلاسيك', 'قديم', 'الكلاسيك', 'القديم', 'refined'],
  };

  static const Map<String, List<String>> layerAliases = {
    'top': [
      'top note',
      'إفتتاحية',
      'افتتاحية',
      'مقدمة',
      'الافتتاحية',
      'المقدمة',
      'افتتاحيتة',
      'افتتاحيتها',
    ],
    'middle': ['middle note', 'قلب', 'وسط', 'القلب', 'الوسط', 'قلبه', 'قلبها'],
    'base': [
      'base note',
      'قاعدة',
      'أساس',
      'القاعدة',
      'الأساس',
      'قاعدته',
      'قاعدتها',
    ],
  };
}
